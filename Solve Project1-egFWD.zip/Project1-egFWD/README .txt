https://d2500xeuf0wzmn.cloudfront.net/index.html

http://my-048858542419-bucket.s3-website-us-east-1.amazonaws.com/